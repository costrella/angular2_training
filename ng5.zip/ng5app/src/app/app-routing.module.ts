import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ItemsComponent} from './components/items/items/items.component';
import {ItemDetailsComponent} from './components/items/item-details/item-details.component';
import {SurveyComponent} from './components/survey/survey.component';
import {WorkersComponent} from './components/workers/workers.component';
import {RegisterComponent} from "./components/register/register.component";
import {InitComponent} from "./components/init/init.component";

const routes: Routes = [
    {path: 'home', component: InitComponent},
    {path: 'items', component: ItemsComponent},
    {path: 'items/:id', component: ItemDetailsComponent},
    {path: 'survey', component: SurveyComponent},
    {path: 'workers', component: WorkersComponent},
    {path: 'register', component: RegisterComponent},
    {path: '**', redirectTo: 'home'}
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: []
})
export class AppRoutingModule {
}
