import {BrowserModule} from "@angular/platform-browser";
import {NgModule} from "@angular/core";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {AppComponent} from "./components/root/app.component";
import {AuthService} from "./services/auth/auth.service";
import {FileUploadComponent} from "./components/upload/file-upload.component";
import {WorkersComponent} from "./components/workers/workers.component";
import {MapToIterablePipe} from "./pipes/array-pipes";
import {CamelCaseToSignPipe} from "./pipes/camel-case-to-sign";
import {AuthComponent} from "./components/auth/auth.component";
import {ItemsComponent} from "./components/items/items/items.component";
import {DataGridRowComponent} from "./components/data-grid/data-grid-row/data-grid-row.component";
import {DataGridComponent} from "./components/data-grid/data-grid.component";
import {ItemDetailsComponent} from "./components/items/item-details/item-details.component";
import {SearchPipe} from "./pipes/search-pipe";
import {ModalConfirmComponent} from "./components/modal/remove/modal-confirm.component";
import {ModalAddComponent} from "./components/modal/add/modal-add.component";
import {SearchComponent} from "./components/search/search.component";
import {SurveyComponent} from "./components/survey/survey.component";
import {AppRoutingModule} from "./app-routing.module";
import {ValidatorComponent} from "./components/validator/validator.component";
import {LimitPipe} from "./pipes/limit.pipe";
import {TranslatePipe} from "./pipes/translate.pipe";
import {CORSInterceptor} from "./shared/xhr-interceptor";
import {StateService} from "./shared/state.service";
import {GetFromObjectPipe} from "./pipes/get-from-object.pipe";
import {RegisterComponent} from "./components/register/register.component";
import {FooterComponent} from "./components/footer/footer.component";
import {AddWorkerComponent} from "./components/add-worker/add-worker.component";
import {SetColorDirective} from "./directives/set-color.directive";
import {NgbModule} from "@ng-bootstrap/ng-bootstrap";
import {HTTP_INTERCEPTORS, HttpClientModule} from "@angular/common/http";
import {InitComponent} from './components/init/init.component';

@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        ReactiveFormsModule, FormsModule,
        AppRoutingModule,
        NgbModule.forRoot()
    ],
    declarations: [
        AppComponent,
        AuthComponent,
        ItemsComponent, DataGridRowComponent, DataGridComponent, ItemDetailsComponent,
        RegisterComponent,
        SurveyComponent,
        SearchComponent, SearchPipe,
        ModalAddComponent, ModalConfirmComponent,
        CamelCaseToSignPipe, MapToIterablePipe,
        FileUploadComponent,
        WorkersComponent, ValidatorComponent, LimitPipe,
        TranslatePipe,
        GetFromObjectPipe,
        FooterComponent,
        AddWorkerComponent,
        SetColorDirective,
        InitComponent
    ],
    providers: [
        AuthService,
        StateService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: CORSInterceptor,
            multi: true,
        }
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
