import {async, inject, TestBed} from "@angular/core/testing";
import {RouterTestingModule} from "@angular/router/testing";
import {Location} from "@angular/common";
import {Router} from "@angular/router";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {AuthService} from "./services/auth/auth.service";
import {SurveyComponent} from "./components/survey/survey.component";
import {MapToIterablePipe} from "./pipes/array-pipes";
import {CamelCaseToSignPipe} from "./pipes/camel-case-to-sign";
import {AppComponent} from "./components/root/app.component";
import {AuthComponent} from "./components/auth/auth.component";
import {ValidatorComponent} from "./components/validator/validator.component";
import {TranslatePipe} from "./pipes/translate.pipe";
import {StateService} from "./shared/state.service";
import {FooterComponent} from "./components/footer/footer.component";
import {SetColorDirective} from "./directives/set-color.directive";
import {HttpClientTestingModule} from "@angular/common/http/testing";

describe('routing', () => {

    let router,
        location;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [
                AuthComponent,
                AppComponent,
                SurveyComponent,
                MapToIterablePipe,
                CamelCaseToSignPipe,
                ValidatorComponent,
                TranslatePipe,
                FooterComponent,
                SetColorDirective
            ],
            imports: [
                RouterTestingModule.withRoutes([
                    {path: 'survey', component: SurveyComponent}
                ]),
                ReactiveFormsModule,
                HttpClientTestingModule,
                FormsModule
            ],
            providers: [
                AuthService,
                StateService
            ]
        });
    });

    beforeEach(inject([Router, Location], (_router: Router, _location: Location) => {
        router = _router;
        location = _location;
    }));

    it('should go survey', async(() => {
        const appComponent = TestBed.createComponent(AppComponent);
        appComponent.detectChanges();
        router.navigate(['/survey']).then(() => {
            expect(location.path()).toBe('/survey');
            expect(appComponent.nativeElement.innerHTML).toContain('teacher evaluation');
        });
    }));
});
