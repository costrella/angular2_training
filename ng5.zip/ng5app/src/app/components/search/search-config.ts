interface SearchControlInterface {
    tag: string;
    type: string;
    name: string;
    value?: string;
    opt?: string[];
}

export class SearchControl implements SearchControlInterface {
    constructor(public tag,
                public type,
                public name,
                public value ?,
                public opt ?) {
    }
}

export class SearchConfig {
    controls: SearchControl[];

    constructor(controls?) {
        this.controls = controls || [];
    }

    add(control: SearchControl) {
        this.controls.push(control);
    }
}
