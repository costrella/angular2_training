import {AfterViewInit, Component, Input, OnInit, ViewChild} from '@angular/core';
import {SearchControl} from './search-config';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Component({
    selector: 'search',
    templateUrl: './search.component.html'
})

export class SearchComponent implements AfterViewInit {
    @Input() controls: SearchControl[];
    @Input() filters: BehaviorSubject<any>;
    @ViewChild('searchForm') searchForm;

    ngAfterViewInit(): void {
        this.searchForm
            .valueChanges
            .subscribe((value) => {
                this.filters.next({...this.filters.getValue(), ...value});
            });
    }

    clear() {
        this.searchForm.reset();
        this.filters.next({});
    }
}
