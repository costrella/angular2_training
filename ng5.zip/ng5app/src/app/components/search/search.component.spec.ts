import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {SearchComponent} from './search.component';
import {SearchConfig, SearchControl} from './search-config';
import {CamelCaseToSignPipe} from '../../pipes/camel-case-to-sign';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {ItemsFilters} from '../items/items/items-filters';
import {FormsModule, NgForm} from "@angular/forms";
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core";

describe('search component', () => {

    let fixture: ComponentFixture<SearchComponent>,
        instance: SearchComponent,
        element: DebugElement,
        form: NgForm,
        searchConfig: SearchConfig;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [
                SearchComponent,
                CamelCaseToSignPipe
            ],
            imports: [FormsModule]
        });

        fixture = TestBed.createComponent(SearchComponent);
        instance = fixture.componentInstance;
        searchConfig = new SearchConfig();
        searchConfig.add(new SearchControl('input', 'text', 'title'));
        searchConfig.add(new SearchControl('input', 'number', 'price'));
        instance.controls = searchConfig.controls;
        instance.filters = new BehaviorSubject(new ItemsFilters());
        element = fixture.debugElement;
        form = instance.searchForm;
        fixture.detectChanges();
    });

    function updateTitle(value) {
        const inputTitle: HTMLInputElement = element.query(By.css('input[ng-reflect-name=title]')).nativeElement;
        inputTitle.value = value;
        inputTitle.dispatchEvent(new Event('input'));
    }

    it('should render inputs according to controls', () => {
        const inputs = element.queryAll(By.css('input'));
        expect(inputs.length).toBe(searchConfig.controls.length);
    });

    it('should update form value after input title change', async(() => {
        fixture
            .whenStable()
            .then(() => {
                updateTitle('tomato');
                expect(form.value.title).toBe('tomato');
            });
    }));

    it('filters.next() should be called after input title change', async(() => {
        spyOn(instance.filters, 'next');
        expect(instance.filters.next).not.toHaveBeenCalled();
        fixture
            .whenStable()
            .then(() => {
                updateTitle('tomato');
                expect(instance.filters.next).toHaveBeenCalled();
            });
    }));

    it('filters.value.title should be tomato after input title change', async(() => {
        instance
            .filters
            .subscribe(
                ({title}) => {
                    if (title) {
                        expect(title).toBe('tomato');
                    } else {
                        expect(title).toBe(''); // init value
                    }
                });

        fixture.whenStable().then(() => {
            updateTitle('tomato');
            expect(instance.filters.getValue().title).toBe('tomato');
        });
    }));

    it('should clear filters.value and form.value', async(() => {
        fixture
            .whenStable()
            .then(() => {
                updateTitle('tomato');
                expect(instance.filters.value.title).toEqual('tomato');
                expect(form.value).toEqual({title: 'tomato', price: ''});

                instance.clear();
                expect(instance.filters.value).toEqual({});
                expect(form.value).toEqual({title: null, price: null});
            });
    }));

});
