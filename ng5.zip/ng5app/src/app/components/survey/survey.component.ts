import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {Settings} from '../../shared/settings';
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/filter";

@Component({
    templateUrl: './survey.component.html'
})
export class SurveyComponent implements OnInit {
    surveyForm: FormGroup;
    range: Array<number> = [1, 2, 3, 4, 5];
    submitted: Boolean = false;
    formSent: Boolean = false;

    constructor(private http: HttpClient) {
    }

    ngOnInit() {
        this.surveyForm = new FormGroup({
            evaluate: new FormGroup({
                preparing: new FormControl('', Validators.required),
                knowledgeTransfer: new FormControl('', Validators.required),
                skills: new FormControl('', Validators.required),
                communicative: new FormControl('', Validators.required),
                materials: new FormControl('', Validators.required)
            }),
            name: new FormControl('', Validators.required),
            whatWasOk: new FormControl(''),
            whatWeCanImprove: new FormControl(''),
            token: new FormControl('', Validators.required)
        });
    }

    sendForm(form) {
        this.submitted = true;
        if (form.valid) {
            this.http
                .post<{ ok, error }>(Settings.SURVEY_END_POINT, JSON.stringify(form.value))
                .filter(({ok, error}): boolean => {
                    if (!ok) {
                        alert(error);
                        return false;
                    } else {
                        return true;
                    }
                })
                .subscribe(
                    response => {
                        this.formSent = true;
                        this.submitted = false;
                        this.clearForm(form);
                    });
        }
    }

    clearForm(form) {
        for (const name in form.controls) {
            if (form.controls.hasOwnProperty(name)) {
                const formEl = form.get(name);
                switch (true) {
                    case formEl instanceof FormControl:
                        formEl.setValue('');
                        break;
                    case formEl instanceof FormGroup:
                        this.clearForm(formEl);
                        break;
                }
            }
        }
    }
}
