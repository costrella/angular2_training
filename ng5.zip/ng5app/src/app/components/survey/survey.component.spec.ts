import {FormControl, ReactiveFormsModule, FormGroup} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {ComponentFixture, TestBed} from '@angular/core/testing';
import {SurveyComponent} from './survey.component';
import {CamelCaseToSignPipe} from '../../pipes/camel-case-to-sign';
import {MapToIterablePipe} from '../../pipes/array-pipes';
import {ValidatorComponent} from '../validator/validator.component';
import {TranslatePipe} from '../../pipes/translate.pipe';
import {DebugElement} from "@angular/core";
import {By} from "@angular/platform-browser";
import {StateService} from "../../shared/state.service";
import {HttpClientTestingModule} from "@angular/common/http/testing";

describe('SurveyComponent', () => {

    let fixture: ComponentFixture<SurveyComponent>,
        instance: SurveyComponent,
        element: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [
                SurveyComponent,
                ValidatorComponent,
                CamelCaseToSignPipe,
                MapToIterablePipe,
                TranslatePipe
            ],
            imports: [
                HttpModule,
                ReactiveFormsModule,
                HttpClientTestingModule
            ],
            providers: [
                StateService
            ]
        });

        fixture = TestBed.createComponent(SurveyComponent);
        instance = fixture.componentInstance;
        element = fixture.debugElement;
        fixture.detectChanges();
    });

    it('should update view when form model is changed', () => {
        const newVal = 'Joe';
        (<FormControl>instance.surveyForm.get('name')).setValue(newVal);
        fixture.detectChanges();
        const nameField: HTMLInputElement = element.query(By.css('input[formControlName=name]')).nativeElement;
        expect(nameField.value).toBe(newVal);
    });

    it('should display 7 errors and dont display sent info', () => {
        const form = element.query(By.css('form')).nativeElement;
        form.dispatchEvent(new Event('submit'));
        fixture.detectChanges();
        const errors = element.queryAll(By.css('.badge-danger'));
        expect(errors.length).toBe(7);
        expect(instance.formSent).toBe(false);
    });

    it('should add active class and display 6 errors', () => {
        const form = element.query(By.css('form')).nativeElement;
        form.dispatchEvent(new Event('submit'));
        const evaluate = (<FormControl>instance.surveyForm.get('evaluate'));
        const preparing = (<FormControl>evaluate.get('preparing'));
        preparing.setValue(2);
        fixture.detectChanges();

        const activeCount = element.queryAll(By.css('.active')).length;
        const errorsCount = element.queryAll(By.css('.badge-danger')).length;
        expect(activeCount).toBe(1);
        expect(errorsCount).toBe(6);
    });

    it('should add active class to all els in evaluate and remove all errors', () => {
        const form = element.query(By.css('form')).nativeElement;
        const evaluate = (<FormGroup>instance.surveyForm.get('evaluate'));
        const name = (<FormControl>instance.surveyForm.get('name'));
        const token = (<FormControl>instance.surveyForm.get('token'));

        for (const key in (<FormGroup>evaluate).controls) {
            if (evaluate.controls[key]) {
                const control = evaluate.get(key);
                const random = Math.ceil(Math.random() * 4);
                control.setValue(random);
            }
        }
        name.setValue('Joe');
        token.setValue('always');

        form.dispatchEvent(new Event('submit'));
        fixture.detectChanges();

        const activeCount = element.queryAll(By.css('.active')).length;
        const errorsCount = element.queryAll(By.css('.badge-danger')).length;
        const sentMsg = element.query(By.css('.alert.alert-success'));

        expect(activeCount).toBe(5);
        expect(errorsCount).toBe(0);
        expect(sentMsg).toBeDefined();
    });

});
