import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {CustomValidators} from "../../shared/custom-validators";

@Component({
    selector: 'app-register',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

    registerForm: FormGroup;

    ngOnInit() {
        this.registerForm = new FormGroup({
            name: new FormControl('', Validators.compose([
                Validators.required,
                Validators.minLength(3)
            ])),
            password: new FormControl('', Validators.compose([
                Validators.required,
                Validators.pattern(/^(?=.*\d)(?=.*[a-zA-Z]).{4,8}$/)
            ])),
            emailGroup: new FormGroup({
                email: new FormControl('', Validators.email),
                emailConfirm: new FormControl('')
            }, CustomValidators.equalEmailsRequired),
            birthDate: new FormControl('', CustomValidators.passedDateRequired),
            hobbies: new FormGroup({
                tv: new FormControl(''),
                music: new FormControl(''),
                sport: new FormControl(''),
                travel: new FormControl(''),
            }, CustomValidators.atLeastOneShouldBeSelected)
        });
    }

    sendForm(form) {
        if (form.valid) {
            alert(JSON.stringify(form.value, null, 4));
            form.reset();
        } else {
            console.error('form invalid');
        }
    }

}
