import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {RegisterComponent} from "./register.component";
import {ReactiveFormsModule} from "@angular/forms";
import {ValidatorComponent} from "../validator/validator.component";
import {MapToIterablePipe} from "../../pipes/array-pipes";
import {TranslatePipe} from "../../pipes/translate.pipe";
import {StateService} from "../../shared/state.service";

describe('Register Component', () => {
    let component: RegisterComponent;
    let fixture: ComponentFixture<RegisterComponent>;

    beforeEach(async(() => {
        TestBed
            .configureTestingModule({
                declarations: [
                    RegisterComponent,
                    ValidatorComponent,
                    MapToIterablePipe,
                    TranslatePipe
                ],
                imports: [
                    ReactiveFormsModule
                ],
                providers: [
                    StateService
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RegisterComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
