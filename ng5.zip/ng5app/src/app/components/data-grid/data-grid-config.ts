export interface DataGridItemInterface {
    key: string;
    type?: string;
}

export class DataGridItemTypes {
    static input = 'input';
    static img = 'img';
    static text = 'text';
}

export class DataGridItem implements DataGridItemInterface {
    constructor(public key, public type?) {

    }
}

export class DataGridConfig {
    data: DataGridItem[];

    constructor(items?) {
        this.data = items || [];
    }

    add(item: DataGridItem) {
        this.data.push(item);
    }
}