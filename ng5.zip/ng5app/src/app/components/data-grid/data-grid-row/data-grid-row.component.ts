import {Component, Input} from '@angular/core';
import {Subject} from "rxjs/Subject";

@Component({
    selector: '[data-grid-row]',
    templateUrl: './data-grid-row.component.html'
})
export class DataGridRowComponent {
    @Input() model: any;
    @Input() config: {}[];
    @Input() access: boolean;
    @Input() itemAction: Subject<any>;

    constructor() {
    }

    update(key, data) {
        this.itemAction.next({type: 'update', data: {...this.model, [key]: data}});
    }

    remove(data) {
        this.itemAction.next({type: 'remove', data});
    }

    goTo(data) {
        this.itemAction.next({type: 'navigate', data});
    }
}
