import {ComponentFixture, TestBed} from '@angular/core/testing';
import {DataGridComponent} from './data-grid.component';
import {DataGridRowComponent} from './data-grid-row/data-grid-row.component';
import {DataGridConfig, DataGridItem, DataGridItemTypes} from "./data-grid-config";
import {ModalConfirmComponent} from '../modal/remove/modal-confirm.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core";
import {Subject} from "rxjs/Subject";

describe('data grid component', () => {

    let fixture: ComponentFixture<DataGridComponent>;
    let element: DebugElement;
    let instance: DataGridComponent;
    let itemsMock;
    let dgConfig: DataGridConfig;

    beforeEach(() => {
        TestBed
            .configureTestingModule({
                imports: [
                    NgbModule.forRoot()
                ],
                declarations: [
                    DataGridComponent,
                    DataGridRowComponent,
                    ModalConfirmComponent
                ]
            });

        fixture = TestBed.createComponent(DataGridComponent);
        element = fixture.debugElement;
        instance = fixture.componentInstance;
        itemsMock = [
            {id: 0, title: 'strawberry', img: '', price: 2},
            {id: 1, title: 'tomato', img: '', price: 1}
        ];
        instance.data = itemsMock;
        instance.itemAction = new Subject();

        dgConfig = new DataGridConfig();
        dgConfig.add(new DataGridItem('title', DataGridItemTypes.text));
        instance.config = dgConfig.data;
        fixture.detectChanges();
    });

    describe('rows', () => {

        it('should be 2', () => {
            const rows = element.queryAll(By.directive(DataGridRowComponent));
            expect(rows.length).toBe(2);
        });

        it('should contains proper text', () => {
            const rows = element.queryAll(By.directive(DataGridRowComponent));
            expect(rows[0].nativeElement.innerText).toContain('strawberry');
            expect(rows[1].nativeElement.innerText).toContain('tomato');
        });

        it('should display delete button when user is logged in', () => {
            const rows = element.queryAll(By.directive(DataGridRowComponent));
            instance.access = true;
            fixture.detectChanges();
            const btn = rows[0].query(By.css('.btn-danger'));
            expect(btn).toBeTruthy();
        });

    });

    describe('headers', () => {

        it('should be two', () => {
            const headers = element.queryAll(By.css('th'));
            expect(dgConfig.data.length + 1).toBe(2);
            expect(dgConfig.data.length + 1).toBe(headers.length);
        });

        it('should be three', () => {
            dgConfig.add(new DataGridItem('price', DataGridItemTypes.input));
            fixture.detectChanges();
            const headers = element.queryAll(By.css('th'));
            expect(dgConfig.data.length + 1).toBe(3);
            expect(dgConfig.data.length + 1).toBe(headers.length);
        });

    })

});
