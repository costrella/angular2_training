import {Component, Input} from '@angular/core';
import {Subject} from "rxjs/Subject";

@Component({
    selector: 'datagrid',
    templateUrl: './data-grid.component.html'
})

export class DataGridComponent {
    @Input() data: any[];
    @Input() config: {}[];
    @Input() access: boolean;
    @Input() itemAction: Subject<any>;
}
