import {ComponentFixture, TestBed} from "@angular/core/testing";
import {AuthComponent} from "./auth.component";
import {AuthService} from "../../services/auth/auth.service";
import {FormsModule} from "@angular/forms";
import {StateService} from "../../shared/state.service";
import {DebugElement} from "@angular/core";
import {Observable} from "rxjs/Observable";
import "rxjs/add/observable/of";
import {Settings} from "../../shared/settings";
import {HttpClientTestingModule, HttpTestingController, TestRequest} from "@angular/common/http/testing";
import {By} from "@angular/platform-browser";

describe('auth component', () => {

    let authService: AuthService,
        stateService: StateService,
        fixture: ComponentFixture<AuthComponent>,
        instance: AuthComponent,
        element: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [
                AuthComponent
            ],
            imports: [
                FormsModule,
                HttpClientTestingModule
            ],
            providers: [
                AuthService,
                StateService
            ]
        });

        fixture = TestBed.createComponent(AuthComponent);
        instance = fixture.componentInstance;
        element = fixture.debugElement;
        authService = TestBed.get(AuthService);
        stateService = TestBed.get(StateService);

    });

    describe('login form', () => {

        it('should be display after detect changes', () => {
            fixture.detectChanges();
            const loginForm = element.query(By.css('form'));
            expect(loginForm).toBeTruthy();
        });

        it('should not be display after login', () => {
            spyOn(authService, 'logIn').and.returnValue(Observable.of({ok: 1}));
            instance.logIn({});
            expect(authService.logIn).toHaveBeenCalled();

            fixture.detectChanges();
            const loginForm = element.query(By.css('form'));
            expect(loginForm).toBeFalsy();
        });

    });

    describe('stateService.isLogged ', () => {

        let req: TestRequest;

        beforeEach(() => {
            const http = TestBed.get(HttpTestingController);
            instance.logIn({});
            req = http.expectOne(Settings.LOGIN_END_POINT);
        });

        it('should be true', () => {
            req.flush({ok: 1});
            expect(stateService.isLogged).toBeTruthy();
        });

        it('should be false', () => {
            req.flush({ok: 0});
            expect(stateService.isLogged).toBeFalsy();
        });

    });

});