import {Component} from '@angular/core';
import {AuthService} from '../../services/auth/auth.service';
import {StateService} from '../../shared/state.service';

@Component({
    selector: 'app-auth',
    templateUrl: './auth.component.html',
    styles: [`
        .form-inline > input {
            width: 60px;
            display: inline-block;
        }
    `]
})
export class AuthComponent {

    constructor(public authService: AuthService,
                public stateService: StateService) {
        this.authService
            .isAuthenticated()
            .subscribe(({ok}) => this.stateService.isLogged = ok);
    }

    logIn(formValue) {
        this.authService
            .logIn(formValue)
            .subscribe(({ok}) => this.stateService.isLogged = ok);
    }

    logOut() {
        this.authService
            .logOut()
            .subscribe(response => this.stateService.isLogged = false);
    }

}
