import {ModalDismissReasons, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';

export class ModalBase {

    openedModal: NgbModalRef;

    constructor(private modalService) {

    }

    open(content) {
        this.openedModal = this.modalService.open(content);

        this.openedModal
            .result
            .then((result) => this.go(result))
            .catch((reason) => console.log(this.getDismissReason(reason)));
    }

    check(form) {
        if (form.valid) {
            this.openedModal.close(form);
        } else {
            console.log('form invalid');
        }
    }

    go(result) {
        throw new Error('you should override go method');
    }

    getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}
