import {Component, Output, EventEmitter, Input} from '@angular/core';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {ModalBase} from '../modal-base';

@Component({
    selector: 'modal-confirm',
    templateUrl: './modal-confirm.component.html'
})
export class ModalConfirmComponent extends ModalBase {
    @Input() text: string;
    @Output() outputAction = new EventEmitter<string>();

    constructor(modalService: NgbModal) {
        super(modalService);
    }

    go(result) {
        this.outputAction.emit();
    }
}
