import {Component, Input} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {Settings} from '../../../shared/settings';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {ModalBase} from '../modal-base';
import {Subject} from 'rxjs/Subject';
import {ItemModel} from '../../items/item-model';
import {ServerValidators} from "../../../shared/custom-validators";

@Component({
    selector: 'modal-add',
    templateUrl: './modal-add.component.html',
    providers: [
        ServerValidators
    ]
})

export class ModalAddComponent extends ModalBase {
    addItemForm: FormGroup;
    uploadUrl: string;
    @Input() newItem: Subject<any>;

    constructor(modalService: NgbModal, serverValidators: ServerValidators) {
        super(modalService);
        this.addItemForm = new FormGroup({
            title: new FormControl('', Validators.compose([
                Validators.required,
                Validators.minLength(3)
            ]), serverValidators.makeCheck.bind(serverValidators)),
            imgSrc: new FormControl(''),
            price: new FormControl('', Validators.compose([
                Validators.required,
                Validators.pattern('[1-9]+[0-9]*')
            ])),
            category: new FormControl('', Validators.required)
        });
        this.uploadUrl = Settings.UPLOAD_END_POINT;
    }

    go({value}) {
        this.newItem.next({type: 'add', data: new ItemModel(value)});
    }

}
