import {Component} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ItemsService} from '../../../services/items/items.service';
import {IItemModel} from '../item-model';
import {Observable} from 'rxjs/Observable';

@Component({
    selector: 'item-details',
    templateUrl: './item-details.component.html',
    providers: [
        ItemsService
    ]
})
export class ItemDetailsComponent {
    model: Observable<IItemModel>;

    constructor(private route: ActivatedRoute,
                itemsService: ItemsService,
                private router: Router) {
        route.params
            .subscribe(
                (params: { id }) => {
                    this.model = itemsService.get(params.id)//.publishReplay().refCount();
                });
    }

    goBack() {
        this.router.navigate(['/items']);
    }

}
