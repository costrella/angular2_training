import {Component, OnInit} from '@angular/core';
import {ItemsService} from '../../../services/items/items.service';
import {IItemModel} from '../item-model';
import {SearchConfig, SearchControl} from '../../search/search-config';
import {ItemsFilters} from './items-filters';

import {Router} from "@angular/router";
import {DataGridConfig, DataGridItem, DataGridItemTypes} from "../../data-grid/data-grid-config";
import {StateService} from "../../../shared/state.service";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import {Subject} from "rxjs/Subject";
import "rxjs/add/operator/debounceTime";

@Component({
    selector: 'items',
    templateUrl: './items.component.html',
    providers: [
        ItemsService
    ]
})
export class ItemsComponent implements OnInit {

    searchConfig: SearchConfig;
    dataGridConfig: DataGridConfig;
    filters: BehaviorSubject<ItemsFilters>;
    itemAction: Subject<any>;
    items: IItemModel[];
    total: number;

    constructor(public itemsService: ItemsService,
                public statusService: StateService,
                public router: Router) {
    }

    ngOnInit(): void {
        this.searchConfig = new SearchConfig();
        this.searchConfig.add(new SearchControl('input', 'text', 'title'));
        this.searchConfig.add(new SearchControl('input', 'number', 'priceFrom'));
        this.searchConfig.add(new SearchControl('select', '', 'category', '', ['', 'food', 'clothes']));
        this.searchConfig.add(new SearchControl('select', '', 'itemsPerPage', 5, [2, 5, 10]));

        this.dataGridConfig = new DataGridConfig();
        this.dataGridConfig.add(new DataGridItem('title'));
        this.dataGridConfig.add(new DataGridItem('price', DataGridItemTypes.input));
        this.dataGridConfig.add(new DataGridItem('imgSrc', DataGridItemTypes.img));

        this.filters = new BehaviorSubject(new ItemsFilters());
        this.itemAction = new Subject();

        this.filters
            .debounceTime(500)
            .subscribe(() => this.fetchItems());

        this.itemAction
            .subscribe((action) => this[action.type](action.data));
    }

    fetchItems() {
        this.itemsService
            .fetch(this.filters.getValue())
            .subscribe(
                (result) => {
                    this.items = result.data;
                    this.total = result.total;
                });
    }

    updateFilters(key, value) {
        this.filters.next(Object.assign(new ItemsFilters(), this.filters.value, {[key]: value}));
    }

    add(item: IItemModel) {
        this.itemsService
            .add(item)
            .subscribe(() => this.fetchItems());
    }

    update(item: IItemModel) {
        this.itemsService
            .update(item)
            .subscribe();
    }

    remove(item) {
        this.itemsService
            .remove(item.id)
            .subscribe(() => this.fetchItems());
    }

    navigate(item) {
        this.router.navigate(['items/' + item.id]);
    }

}
