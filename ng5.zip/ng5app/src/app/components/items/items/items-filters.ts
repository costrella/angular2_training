export class ItemsFilters {
    constructor(public title = '',
                public priceFrom = 0,
                public category = '',
                public currentPage = 1,
                public itemsPerPage = 5) {
    }
}
