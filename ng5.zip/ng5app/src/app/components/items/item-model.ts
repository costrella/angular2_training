export interface IItemModel {
    category: string;
    id?: number;
    imgSrc: string;
    price: number;
    title: string;
}

export class ItemModel implements IItemModel {
    category: string;
    id: number;
    imgSrc: string;
    price: number;
    title: string;

    constructor(params) {
        for (let key in params) {
            if (params.hasOwnProperty(key)) {
                this[key] = params[key];
            }
        }
    }

    static FromJsonList(list) {
        return list.json().data.map((item) => {
            return new ItemModel(item);
        });
    }
}