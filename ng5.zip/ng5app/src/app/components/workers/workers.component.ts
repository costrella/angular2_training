import {Component, OnInit} from '@angular/core';
import {WorkersService} from '../../services/workers/workers.service';
import {WorkerModel} from '../add-worker/worker-model';
import {SearchConfig, SearchControl} from '../search/search-config';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Subject";
import {DataGridConfig, DataGridItem, DataGridItemTypes} from "../data-grid/data-grid-config";
import {StateService} from "../../shared/state.service";

@Component({
    templateUrl: './workers.component.html',
    providers: [
        WorkersService
    ]
})
export class WorkersComponent implements OnInit {
    searchConfig: SearchConfig;
    dataGridConfig: DataGridConfig;
    filters: BehaviorSubject<any>;
    workers: Observable<any>;
    workerAction: Subject<any>;

    constructor(public workersService: WorkersService,
                public statusService: StateService) {
    }

    ngOnInit(): void {
        this.searchConfig = new SearchConfig();
        this.searchConfig.add(new SearchControl('input', 'text', 'name'));
        this.searchConfig.add(new SearchControl('select', '', 'category', '', ['', 'sales', 'support']));

        this.dataGridConfig = new DataGridConfig();
        this.dataGridConfig.add(new DataGridItem('name'));
        this.dataGridConfig.add(new DataGridItem('phone', DataGridItemTypes.input));

        this.filters = new BehaviorSubject({});
        this.workerAction = new Subject();
        this.workers = this.workersService.fetch();

        this.workerAction
            .subscribe((action) => this[action.type](action.data));
    }

    add(worker: WorkerModel) {
        this.workersService
            .add(worker)
            .subscribe(() => this.workers = this.workersService.fetch());
    }

    update(worker: WorkerModel) {
        this.workersService
            .update(worker)
            .subscribe();
    }

    remove(worker: WorkerModel) {
        this.workersService
            .remove(worker.id)
            .subscribe(() => this.workers = this.workersService.fetch());
    }

    navigate(worker) {
        alert('WORKER DETAILS \n' + JSON.stringify(worker, null, 4));
    }

}
