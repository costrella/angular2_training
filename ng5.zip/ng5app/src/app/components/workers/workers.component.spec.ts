import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {WorkersComponent} from "./workers.component";
import {DataGridComponent} from "../data-grid/data-grid.component";
import {DataGridRowComponent} from "../data-grid/data-grid-row/data-grid-row.component";
import {SearchPipe} from "../../pipes/search-pipe";
import {GetFromObjectPipe} from "../../pipes/get-from-object.pipe";
import {SearchComponent} from "../search/search.component";
import {ModalConfirmComponent} from "../modal/remove/modal-confirm.component";
import {CamelCaseToSignPipe} from "../../pipes/camel-case-to-sign";
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core";
import {NgbModule} from "@ng-bootstrap/ng-bootstrap";
import {StateService} from "../../shared/state.service";
import {AddWorkerComponent} from "../add-worker/add-worker.component";
import {HttpClientTestingModule} from "@angular/common/http/testing";
import {HttpInMemoryWebApiModule, InMemoryDbService} from "angular-in-memory-web-api";

export class InMemHeroService implements InMemoryDbService {
    createDb() {
        return {
            authorize: {ok: 1},
            workers: require('../../shared/mocks/workers.json')
        };
    }
}

describe('Workers component', () => {
    const userServiceStub = {
        isLogged: true
    };

    let fixture: ComponentFixture<WorkersComponent>;
    let element: DebugElement;
    let instance: WorkersComponent;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [
                WorkersComponent,
                DataGridComponent,
                DataGridRowComponent,
                SearchPipe,
                GetFromObjectPipe,
                SearchComponent,
                ModalConfirmComponent,
                CamelCaseToSignPipe,
                AddWorkerComponent
            ],
            imports: [
                HttpClientTestingModule,
                ReactiveFormsModule,
                FormsModule,
                NgbModule.forRoot(),
                HttpInMemoryWebApiModule.forRoot(InMemHeroService)
            ],
            providers: [
                {provide: StateService, useValue: userServiceStub}
            ]
        });

        fixture = TestBed.createComponent(WorkersComponent);
        instance = fixture.componentInstance;
        element = fixture.debugElement;
    });

    it('should render workers list', async(() => {
        fixture.detectChanges();
        fixture
            .whenStable()
            .then(() => {
                instance.workers
                    .subscribe(
                        (response) => {
                            fixture.detectChanges();
                            const rows = element.queryAll(By.css('tr'));
                            //expect(response.data.length).toBe(rows.length - 1);
                        });
            });

    }));

    it('should display confirm between remove', async(() => {
        fixture.detectChanges();
        fixture
            .whenStable()
            .then(() => {
                instance.workers
                    .subscribe(
                        () => {
                            fixture.detectChanges();
                            const btnRemove = element.query(By.css('.btn-danger'));
                            btnRemove.triggerEventHandler('click', null);

                            const btnConfirm = document.querySelector('.btn-confirm');
                            expect(btnConfirm).toBeTruthy();
                        });
            });
    }));

});
