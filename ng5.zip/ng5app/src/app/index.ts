export * from './components/root/app.component';
export * from './app.module';
