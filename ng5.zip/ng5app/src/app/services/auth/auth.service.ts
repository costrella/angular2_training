import {Injectable} from '@angular/core';
import {AuthServiceInterface} from './auth.service.interface';
import {Settings} from '../../shared/settings';
import {Observable} from "rxjs/Observable";
import {HttpClient} from "@angular/common/http";
import 'rxjs/add/operator/map';

@Injectable()
export class AuthService implements AuthServiceInterface {

    constructor(private http: HttpClient) {
    }

    isAuthenticated(): Observable<any> {
        return this.http.get(Settings.AUTH);
    }

    logIn(formData): Observable<any> {
        return this.http.post(Settings.LOGIN_END_POINT, formData);
    }

    logOut(): Observable<any> {
        return this.http.get(Settings.LOGOUT_END_POINT);
    }

}
