import {Injectable} from '@angular/core';
import {Settings} from '../../shared/settings';
import {IItemModel} from '../../components/items/item-model';
import {CRUDServiceInterface} from '../crud.service.interface';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpParams} from "@angular/common/http";

@Injectable()
export class ItemsService implements CRUDServiceInterface {

    constructor(private http: HttpClient) {
    }

    fetch(filters): Observable<any> {

        let params = new HttpParams();

        for (let key in filters) {
            params = params.append(key, filters[key]);
        }

        return this.http.get(Settings.ITEMS_END_POINT, {params});
    }

    get(id) {
        return this.http
            .get<{ok, data}>(Settings.ITEMS_END_POINT + '/' + id)
            .map((resp) => {
                return resp.data;
            });
    }

    add(item: IItemModel): any {
        return this.http
            .post(Settings.ITEMS_END_POINT, item);
    }

    update(item: IItemModel): any {
        return this.http
            .put(`${Settings.ITEMS_END_POINT}/${item.id}`, item);
    }

    remove(id): any {
        return this.http
            .delete(`${Settings.ITEMS_END_POINT}/${id}`);
    }
}
