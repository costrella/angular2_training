import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'getFromObject'
})
export class GetFromObjectPipe implements PipeTransform {

  transform(obj: any, key:any): any {
    if(obj) {
        return obj[key];
    }
  }

}
