import {TranslatePipe} from './translate.pipe';
import {StateService} from "../shared/state.service";
import {TestBed} from "@angular/core/testing";

describe('Pipe: Translate', () => {

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                StateService
            ]
        });
    });

    it('create an instance', () => {
        const pipe = new TranslatePipe(TestBed.get(StateService));
        expect(pipe).toBeTruthy();
    });

    it('should return pl version', () => {
        const pipe = new TranslatePipe(TestBed.get(StateService));
        const result = pipe.transform('required');
        expect(result).toBe(pipe.dict.pl.required);
    });

    it('should return de version', () => {
        let stateService = TestBed.get(StateService);
        stateService.lang = 'de';
        const pipe = new TranslatePipe(stateService);
        const result = pipe.transform('email');
        expect(result).toBe(pipe.dict.de.email);
    });

});
