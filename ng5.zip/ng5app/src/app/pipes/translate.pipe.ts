import {Pipe, PipeTransform} from '@angular/core';
import {StateService} from "../shared/state.service";

@Pipe({
    name: 'translate'
})
export class TranslatePipe implements PipeTransform {

    dict = {
        pl: {
            required: 'pole wymagane',
            minlength: 'tekst zbyt krótki',
            atLeastOneShouldBeSelected: 'wybierz co najmniej jeden',
            passedDateRequired: 'wymagana przeszła data',
            email: 'email niepoprawny',
            equalEmailsRequired: 'maile nie są zgodnie'
        },
        de: {
            required: 'erforderlich',
            minlength: 'min-Länge',
            atLeastOneShouldBeSelected: 'mindestens ein',
            passedDateRequired: 'das Datum abgelaufen',
            email: 'ungültige E-Mail',
            equalEmailsRequired: 'maile nie są zgodnie po niemiecku'
        }
    };

    lang;

    constructor(private stateService: StateService) {
        this.lang = stateService.lang;
    }

    transform(text: any): any {
        if (text
            && this.lang
            && this.dict[this.lang]
            && this.dict[this.lang][text]) {
            return this.dict[this.lang][text];
        } else {
            return text;
        }
    }

}
