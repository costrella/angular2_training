import { GetFromObjectPipe } from './get-from-object.pipe';

describe('GetFromObjectPipe', () => {
  it('create an instance', () => {
    const pipe = new GetFromObjectPipe();
    expect(pipe).toBeTruthy();
  });
});
