import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import {StateService} from "./state.service";
import {Injectable} from "@angular/core";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import 'rxjs/add/observable/throw';

@Injectable()
export class CORSInterceptor implements HttpInterceptor {
    constructor(private stateService: StateService) {
    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.stateService.unsaved = true;
        const reqClone = req.clone({withCredentials: true});
        return next
            .handle(reqClone)
            .do(evt => {
                if (evt instanceof HttpResponse) {
                    this.stateService.unsaved = false;
                    //console.log('---> status:', evt.status);
                }
            })
            .catch((err) => {
                alert('ERROR \n' + JSON.stringify(err, null, 4));
                return Observable.throw(err)
            });
    }
}