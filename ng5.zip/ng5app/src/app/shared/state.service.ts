import {Injectable} from '@angular/core';

@Injectable()
export class StateService {

    private access: boolean = false;
    unsaved: boolean = false;
    lang: string = 'pl';

    set isLogged(access) {
        this.access = access;
    }

    get isLogged() {
        return this.access;
    }

}
