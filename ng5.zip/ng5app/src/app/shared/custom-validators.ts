import {AbstractControl, FormGroup, ValidationErrors} from "@angular/forms";
import {Injectable} from "@angular/core";
import {Settings} from "./settings";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import "rxjs/add/observable/timer";
import "rxjs/add/operator/switchMapTo";

@Injectable()
export class ServerValidators {
    constructor(private http: HttpClient) {
    }

    makeCheck(control) {
        return Observable.timer(500)
            .switchMapTo(
                this.http
                    .post(Settings.CHECK_TITLE_END_POINT, {title: control.value})
                    .map((resp: any) => {
                        if (!resp.ok) {
                            return {[resp.error]: true};
                        }
                    })
            );
    }
}

export class CustomValidators {
    static equalEmailsRequired(group: FormGroup): ValidationErrors {

        if (!group.value.email || group.value.email !== group.value.emailConfirm) {
            return {
                equalEmailsRequired: true
            };
        }

    };

    static atLeastOneShouldBeSelected(group: FormGroup): ValidationErrors {

        for (let key in group.controls) {
            if (group.controls[key].value) {
                return;
            }
        }

        return {
            atLeastOneShouldBeSelected: true
        }
    };

    static passedDateRequired(control: AbstractControl): ValidationErrors {

        if (Date.parse(control.value) < Date.now()) {
            return;
        }

        return {
            passedDateRequired: true
        }

    }
}