import {browser, By, element} from "protractor";

describe('main menu', () => {

    const
        btnItem = element(By.css('[routerlink=items]')),
        btnWorkers = element(By.css('[routerlink=workers]')),
        btnRegister = element(By.css('[routerlink=register]')),
        btnSurvey = element(By.css('[routerlink=survey]'));

    beforeAll(() => {
        browser.get('/');
    });

    describe('when click button', () => {

        it('items should load /items page', () => {
            btnItem.click();
            expect(browser.getCurrentUrl()).toContain('items');
        });

        it('workers should load /workers page', () => {
            btnWorkers.click();
            expect(browser.getCurrentUrl()).toContain('workers');
        });

        it('register form should load /register-form page', () => {
            btnRegister.click();
            expect(browser.getCurrentUrl()).toContain('register');
        });

        it('survey should load /survey page', () => {
            btnSurvey.click();
            expect(browser.getCurrentUrl()).toContain('survey');
        });

    })

});