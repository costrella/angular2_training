import {$$, browser} from 'protractor';

describe('surveyComponent', function () {

    const labels = $$('label');

    beforeAll(function () {
        browser.get('/survey');
    });

    it('should has 25 labels with input', function () {
        labels.count()
            .then(function (items) {
                expect(items).toBe(25);
                for (let i = 0; i < items; i++) {
                    expect(labels.get(i).$('input').isPresent()).toBe(true);
                }
            });
    });

    it('input with index 0 should have text "1"', function () {
        const el0 = labels.get(0);
        expect(el0.getText()).toBe('1');
    });

    it('input whit index 4 should have text "5"', function () {
        const el4 = labels.get(4);
        expect(el4.getText()).toBe('5');
    });

    it('input with index 0 should be selected after click', function () {
        const el0 = labels.get(0);
        expect(el0.$('input').isSelected()).toBe(false);
        el0.click();
        expect(el0.$('input').isSelected()).toBe(true);
    });

});
