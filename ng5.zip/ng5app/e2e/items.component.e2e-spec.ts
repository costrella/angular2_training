import {$, browser, By, element} from 'protractor';

describe('items view', () => {

    const path = require('path');
    const uniqueTitle = 'test id: ' + Date.now();

    const dataGrid = element(By.tagName('datagrid'));
    const items = dataGrid.all(By.css('[data-grid-row]'));
    const btnLogIn = element(By.buttonText('log in'));
    const btnLogOut = element(By.buttonText('log out'));
    const btnAdd = element(By.buttonText('add item'));
    const searchTitle = element(By.id('search-by-title'));
    const btnRemove = items.get(0).element(By.buttonText('remove'));

    beforeAll(() => {
        browser.get('/items');
        if (btnLogIn.isPresent()) {
            btnLogIn.click();
            expect(btnLogOut.isPresent()).toBe(true);
        }
    });

    describe('when loaded', () => {

        beforeAll(() => {
            browser.get('/items');
        });

        it('should display element dataGrid', function () {
            expect(dataGrid.isPresent()).toBe(true);
        });

        it('should display element search', function () {
            expect(searchTitle.isPresent()).toBe(true);
        });

        it('should display element btnAdd', function () {
            expect(btnAdd.isPresent()).toBe(true);
        });

        it('should have any items in list', function () {
            expect(items.count()).toBeGreaterThan(0);
        });

        describe('and when btnAdd is clicked', () => {

            // modal add
            const addItemForm = element(By.id('add-item-form'));
            const fieldCategory = addItemForm.$('select');
            const fieldTitle = addItemForm.$('input[type=text]');
            const fieldPrice = addItemForm.$('input[type=number]');
            const modalFile = addItemForm.element(By.css('input[type=file]'));
            const btnSend = addItemForm.element(By.buttonText('send item'));

            // modal confirm
            const btnConfirm = $('.btn-confirm');

            beforeAll(() => {
                btnAdd.click();
            });

            it('should display add form', function () {
                expect(addItemForm.isPresent()).toBe(true);
            });

            it('should display title field', function () {
                expect(fieldTitle.isPresent()).toBe(true);
            });

            it('should display price field', function () {
                expect(fieldPrice.isPresent()).toBe(true);
            });

            it('should display btnSend button', function () {
                expect(btnSend.isPresent()).toBe(true);
            });

            it('should add item then find it and remove', function () {
                fieldCategory.element(By.cssContainingText('option', 'food')).click();
                fieldTitle.sendKeys(uniqueTitle);
                fieldPrice.sendKeys(101);
                const absolutePath = path.resolve(__dirname + '/assets/monkey.jpg');
                modalFile.sendKeys(absolutePath);
                btnSend.click();
                searchTitle.sendKeys(uniqueTitle);
                expect(items.count()).toBe(1);
                btnRemove.click();
                btnConfirm.click();
                //browser.switchTo().alert().accept();
                expect(btnConfirm.isPresent()).toBeFalsy();
                expect(items.count()).toBe(0);
            });
        });

    });

});