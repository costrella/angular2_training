import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {AppComponent} from './app.component';
import {routing} from './app.routing';
import {ComponentExample} from './examples/component/main';
import {DirectivesNgExamples} from './examples/directives/main';
import {MouseAndKeyEventsExamples} from './examples/mouse-and-key-events/main';
import {DomElementPropertyExample} from './examples/dom-element-property/main';
import {ServiceExample} from './examples/service/main';
import {PipesExample} from './examples/pipes/main';
import {SetGetExample} from './examples/set-get/main';
import {StylesEncapsulationExample} from './examples/styles-encapsulation/main';
import {HttpExample} from './examples/http/main';
import {RxCalorieCalcExample} from './examples/rxjs/calc';
import {RxGameExample} from './examples/rxjs/game';
import {MessageService, RxCollectionExample} from './examples/rxjs/collection';
import {FormModelDrivenExample} from './examples/form-model-driven/main';
import {RoutesExample} from './examples/routes/main';
import {UploadComponentExample} from './examples/upload/main';
import {NgBootstrapExample} from './examples/ng-bootstrap/main';
import {OnInitCmp, OnInitExample} from './examples/component-lifecycle-hooks/onInit-onDestroy';
import {OnChangeCmp, OnChangesExample} from './examples/component-lifecycle-hooks/onChanges';
import {DoCheckIterableExample, DoCheckList} from './examples/component-lifecycle-hooks/doCheck-iterable';
import {AftersCmp, AfterViewInitExample} from './examples/component-lifecycle-hooks/afterViewInit-afterContentInit';
import {Guard} from './examples/routes/services/guard';
import {AuthService} from './examples/routes/services/auth-service';
import {HomeComponent} from './examples/routes/components/home-component';
import {AboutComponent} from './examples/routes/components/about-component';
import {ProductsComponent} from './examples/routes/components/products-component';
import {MainProductComponent} from './examples/routes/components/products/main-component';
import {InterestProductComponent} from './examples/routes/components/products/interest-component';
import {ProtectedComponent} from './examples/routes/components/protected-component';
import {ByIdProductComponent} from './examples/routes/components/products/by-Id-component';
import {WorkerCardComponent} from './examples/component/worker-card.component';
import {TranslatePipe} from './examples/pipes/translate-pipe';
import {LimiterPipe} from './examples/pipes/limiter-pipe';
import {Compo} from './examples/set-get/compo';
import {MyComponent} from './examples/styles-encapsulation/my-component';
import {Items} from './examples/http/items';
import {FormWithFormGroup} from './examples/form-model-driven/form-model-driven';
import {LoginComponent} from './examples/routes/components/login-component';
import {FileUpload} from './examples/upload/file-upload';
import {InitComponent} from './init.component';
import {ObjectToIterable} from './shared/object-to-iterable';
import {LifeCycleComponent} from './examples/component-lifecycle-hooks/main';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {ModalDemoComponent} from './examples/ng-bootstrap/modal/modal';
import {PaginationExample} from './examples/ng-bootstrap/pagination/pagination';
import {FormTemplateDriven} from './examples/form-template-driven/form-template-driven';
import {FormTemplateDrivenExample} from './examples/form-template-driven/main';
import {AdultValidator} from './examples/form-template-driven/validate-duration.directive';
import {MyColorDirective} from './examples/directives/my-color.directive';
import {DoCheckObjectComponent, DoCheckObjectExampleComponent} from './examples/component-lifecycle-hooks/doCheck-object-keys';
import {SizerComponent} from './examples/component/sizer.component';
import {SearchPipe} from "./examples/pipes/search.pipe";
import {HttpClientModule} from "@angular/common/http";

@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        ReactiveFormsModule, FormsModule,
        NgbModule.forRoot(),
        routing
    ],
    declarations: [
        AppComponent,
        InitComponent,
        WorkerCardComponent,
        TranslatePipe, LimiterPipe, SearchPipe,
        Compo, MyComponent, Items,
        ComponentExample, DirectivesNgExamples, MouseAndKeyEventsExamples, DomElementPropertyExample, ServiceExample,
        PipesExample, SetGetExample, StylesEncapsulationExample, HttpExample, RxCalorieCalcExample,
        RxGameExample, RxCollectionExample, FormModelDrivenExample, FormTemplateDriven, FormTemplateDrivenExample,
        AdultValidator,
        FormWithFormGroup, LoginComponent, FileUpload, ModalDemoComponent, PaginationExample,
        OnInitCmp, OnChangeCmp, DoCheckList, DoCheckObjectComponent, AftersCmp,
        RoutesExample, HomeComponent, AboutComponent, ProductsComponent,
        MainProductComponent, InterestProductComponent, ByIdProductComponent, ProtectedComponent,
        UploadComponentExample, NgBootstrapExample,
        OnInitExample, OnChangesExample, DoCheckIterableExample, DoCheckObjectExampleComponent,
        AfterViewInitExample,
        ObjectToIterable,
        LifeCycleComponent,
        MyColorDirective, SizerComponent
    ],
    providers: [
        Guard,
        AuthService,
        MessageService
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}