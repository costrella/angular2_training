export class API {
    static END_POINT_PREFIX = 'https://api.emitter.pl/';
    //static END_POINT_PREFIX = 'http://localhost:3333/api/';
    static ITEMS_END_POINT = API.END_POINT_PREFIX + 'items';
    static LOGIN_END_POINT = API.END_POINT_PREFIX + 'login';
    static IS_AUTHENTICATED = API.END_POINT_PREFIX + 'auth';
    static UPLOAD_END_POINT = API.END_POINT_PREFIX + 'upload';
    static IMAGE_END_POINT = 'https://api.emitter.pl/assets/admin.png';
}