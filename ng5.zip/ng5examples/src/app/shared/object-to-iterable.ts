import {Pipe} from "@angular/core";
@Pipe({
    name: "objectToIterable"
})
export class ObjectToIterable {
    transform(obj) {
        if (obj) {
            return Object.keys(obj);
        }
    }
}