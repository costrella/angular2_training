import {Component} from "@angular/core";
@Component({
    selector: "form-template-driven",
    templateUrl: "form-template-driven.html"
})

export class FormTemplateDriven {

}