import {Component} from "@angular/core";

@Component({
    template: `
        <div class="card">
            <div class="card-header">TEMPLATE DRIVEN FORM</div>
            <div class="card-body">
                <form-template-driven></form-template-driven>
            </div>
        </div>`
})

export class FormTemplateDrivenExample {

}