import {Component} from '@angular/core';

@Component({
    selector: 'app',

    template: `
        <modal-example></modal-example>
        <hr>
        <pagination-example></pagination-example>
    `
})
export class NgBootstrapExample {

}