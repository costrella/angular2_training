import {Component} from "@angular/core";
@Component({
    selector: 'pagination-example',
    template: `
        <div>Default pagination</div>
        <div>current page: {{page}}</div>
        <ngb-pagination [collectionSize]="250"
                        [maxSize]="5"
                        size="sm"
                        [rotate]="true"
                        [(page)]="page">
        </ngb-pagination>
    `
})
export class PaginationExample {
    page = 4;
}