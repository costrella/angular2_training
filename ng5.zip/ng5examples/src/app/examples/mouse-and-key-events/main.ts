import {Component} from "@angular/core";

@Component({
    selector: "app",
    template: `
        <div class="card">
            <h4 class="card-header">
                Zdarzenia na elementach DOM - otwórz konsole w przeglądarce
            </h4>
            <div class="card-body"
                 (mouseover)="over($event)"
                 (mouseout)="out($event)">
                <input placeholder="write something and press enter"
                       class="form-control"
                       #myInput 
                       (keydown.enter)="action(myInput.value)">
                <button class="btn btn-primary"
                        (click)="action(myInput.value)">
                    click me
                </button>
            </div>
        </div>
    `
})
export class MouseAndKeyEventsExamples {

    styleCopy: any;

    over(evt) {
        console.log(evt.clientX, evt.clientY);
        this.styleCopy = evt.target.style;
        evt.target.style.border = "solid red";
    }

    out(evt) {
        evt.target.style = this.styleCopy;
    }

    action(val) {
        alert('your msg is: ' + val);
    }
}