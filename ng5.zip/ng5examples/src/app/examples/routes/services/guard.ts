import {Injectable} from "@angular/core";
import {CanActivate} from "@angular/router";
import {AuthService} from "./auth-service";

@Injectable()
export class Guard implements CanActivate {
    constructor(private authService: AuthService) {

    }

    canActivate(): boolean {
        if (this.authService.isLogged) {
            return true;
        } else {
            alert('you shall not pass. Try login');
        }
    }
}