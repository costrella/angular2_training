import {Injectable} from "@angular/core";

@Injectable()
export class AuthService {
    signIn(login: string, pass: string) {
        if (login === 'admin' && pass === 'admin') {
            localStorage.setItem('user', login);
        } else {
            alert('bad' + login + pass);
        }
    }

    signOut() {
        localStorage.removeItem('user');
    }

    get isLogged() {
        return !!localStorage.getItem('user');
    }
}