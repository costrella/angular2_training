import {Component} from '@angular/core';

@Component({
    template: `Welcome to the products section. Please select a product above.`
})
export class MainProductComponent {
}
