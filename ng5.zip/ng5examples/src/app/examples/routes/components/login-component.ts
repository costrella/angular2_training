import {Component} from "@angular/core";
import {AuthService} from "../services/auth-service";

@Component({
    selector: "login",
    template: `
        <span *ngIf="!authService.isLogged">
        <input #login value="admin">
        <input type="password" #password value="admin">
        <button class="btn btn-success" (click)="authService.signIn(login.value, password.value)">
            sign in
        </button>
    </span>
        <button class="btn btn-warning" *ngIf="authService.isLogged"
                (click)="authService.signOut()">
            sign out
        </button>
        <span class="badge"
              [ngClass]="{'badge-success':authService.isLogged, 'badge-danger':!authService.isLogged}">
            logged: {{authService.isLogged || 'no'}}
    </span>
        <hr>
    `
})

export class LoginComponent {
    constructor(public authService: AuthService) {

    }
}
