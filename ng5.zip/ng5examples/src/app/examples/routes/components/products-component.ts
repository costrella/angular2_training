import {Component} from "@angular/core";
import {
    Router,
    Routes,
} from "@angular/router";

import {InterestProductComponent} from "./products/interest-component";
import {MainProductComponent} from "./products/main-component";
import {Utils} from "../services/utils";
import {ByIdProductComponent} from "./products/by-Id-component";

@Component({
    providers: [Utils],
    template: `
        <div class="row">
            <div class="col-3">
                <nav class="list-group">
                    <a class="list-group-item" [routerLinkActive]="['active']" [routerLink]="['./main']">main</a>
                    <a class="list-group-item" [routerLinkActive]="['active']" [routerLink]="['./interest']">interest</a>
                    <a class="list-group-item" [class.active]="helpers.setActive(id.value)">
                        byid: <input class="form-control" #id (input)="gotoProduct(id.value)">
                    </a>
                </nav>
            </div>
            <div class="col-9">
                <div class="jumbotron">
                    <router-outlet></router-outlet>
                </div>
            </div>
        </div>
    `
})

export class ProductsComponent {

    constructor(private router: Router, public helpers: Utils) {

    }

    gotoProduct(id) {
        this.router.navigate(['/routes/products', id]);
    }
}


export const productsRoutes: Routes = [
    {path: '', redirectTo: 'main', pathMatch: 'full'},
    {path: "main", component: MainProductComponent},
    {path: 'interest', component: InterestProductComponent},
    {path: ':id', component: ByIdProductComponent}

];