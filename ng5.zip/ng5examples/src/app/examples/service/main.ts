import {Component} from "@angular/core";
import {MyService} from "./my-service";

@Component({
    selector: "app",
    providers: [MyService],
    template: `
        <h3>Time from service:
            <span class="badge badge-info">{{myService.currentTime | date:"H:mm:ss"}}</span>
        </h3>
        <hr>
        <button class="btn btn-success" (click)="myService.updateTime()">update time</button>
    `
})
export class ServiceExample {
    constructor(public myService: MyService) {

    }
}