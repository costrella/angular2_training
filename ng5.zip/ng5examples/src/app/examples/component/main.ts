import {Component} from "@angular/core";

export interface IUser {
    name: string;
    phone: number;
}

@Component({
    selector: "app",
    template: `
        <div class="row">

            <div class="col-6">
                <div class="card">
                    <h4 class="card-header">Example 1 - one way binding with emitter</h4>
                    <div class="card-body">
                        <div class="alert alert-danger">calling to...{{ringing}}</div>
                        <hr>
                        <worker-card [data]="user"
                                     *ngFor="let user of users; let idx = index"
                                     (callEvent)="callTo($event)">
                            <h4>worker {{idx + 1}}</h4>
                        </worker-card>
                    </div>
                </div>
            </div>

            <div class="col-6">
                <div class="card">
                    <h4 class="card-header">Example 2 - two way data binding</h4>
                    <div class="card-body">
                        <div class="alert alert-danger">size: {{size}}</div>
                        <hr>
                        <my-sizer [(size)]="size"></my-sizer>
                    </div>
                </div>
            </div>
        </div>
    `
})

export class ComponentExample {

    users: IUser[];
    ringing: number;
    size: number = 10;

    constructor() {
        this.users = [
            {name: "Jeo", phone: 9939393},
            {name: "Mike", phone: 444444}
        ];
    }

    callTo(phone) {
        this.ringing = phone;
    }
}