import {Component, Input, Output, EventEmitter} from "@angular/core";

@Component({
    selector: "worker-card",
    host: {
        class: "d-inline-block"
    },
    template: `
        <div class="alert alert-info">
            <ng-content></ng-content>
            <div>name: {{data.name}}</div>
            <div>phone: {{data.phone}}</div>
            <button class="btn btn-success"
                    (click)="call(data.phone)">
                call
            </button>
        </div>
    `
})

export class WorkerCardComponent {
    @Input() data;
    @Output() callEvent = new EventEmitter();

    call(phone){
        this.callEvent.emit(phone);
    }
}


