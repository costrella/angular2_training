import {
    Component,
    Input,
    KeyValueDiffers,
    EventEmitter,
    DoCheck, Output
} from '@angular/core';

@Component({
    selector: 'app-do-check-object',
    template: `
        <div class="alert alert-info">
            {{comment.author}} say: {{comment.comment}}
            <hr>
            <button class="btn btn-success" (click)="like()">add like ({{comment.likes}})</button>
        </div>
    `
})
export class DoCheckObjectComponent implements DoCheck {
    @Input() comment: any;
    @Output() onRemove: EventEmitter<any>;
    differ: any;

    constructor(differs: KeyValueDiffers) {
        this.differ = differs.find([]).create();
        this.onRemove = new EventEmitter();
    }

    ngDoCheck(): void {
        const changes = this.differ.diff(this.comment);

        if (changes) {
            changes.forEachAddedItem(r => this.logChange('added', r));
            changes.forEachChangedItem(r => this.logChange('changed', r));
        }
    }

    logChange(action, r) {
        if (action === 'changed') {
            console.log('item:', r.key, action, 'from', r.previousValue, 'to', r.currentValue);
        }
        if (action === 'added') {
            console.log('item:', action, r.key, 'with', r.currentValue);
        }
    }

    like(): void {
        this.comment.likes += 1;
    }
}


@Component({
    template: `
        <h4>
            DoCheck
        </h4>
        <div>
            ngDoCheck gets called to check the changes in the directives in addition to the default algorithm.
            <br>
            The default change detection algorithm looks for differences by comparing bound-property values
            by reference across change detection runs.
        </div>
        <hr>
        <div>you can see effects in browser console</div>
        <div>do click green btn</div>
        <app-do-check-object [comment]="comment"></app-do-check-object>
    `
})
export class DoCheckObjectExampleComponent {
    comment = {author: 'Joe', comment: 'tralala', likes: 12};
}
