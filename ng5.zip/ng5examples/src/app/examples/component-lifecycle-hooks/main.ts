import {Component} from "@angular/core";
import {Routes} from '@angular/router';
import {OnInitExample} from "./onInit-onDestroy";
import {OnChangesExample} from "./onChanges";
import {DoCheckIterableExample} from "./doCheck-iterable";
import {AfterViewInitExample} from "./afterViewInit-afterContentInit";
import {DoCheckObjectExampleComponent} from "./doCheck-object-keys";

@Component({
    template: `
        <div>
            <nav class="col-xs-4">
                <a class="btn btn-primary btn-sm" [routerLinkActive]="['active']" [routerLink]="['./on-init']">onInit/onDestroy</a>
                <a class="btn btn-primary btn-sm" [routerLinkActive]="['active']" [routerLink]="['./on-changes']">OnChanges</a>
                <a class="btn btn-primary btn-sm" [routerLinkActive]="['active']"
                   [routerLink]="['./do-check-iterable']">DoCheckIterable</a>
                <a class="btn btn-primary btn-sm" [routerLinkActive]="['active']"
                   [routerLink]="['./do-check-object']">DoCheckObject</a>
                <a class="btn btn-primary btn-sm" [routerLinkActive]="['active']" [routerLink]="['./after-view-init']">
                    AfterViewInit/AfterContentInit
                </a>
                <hr>
            </nav>
            <div class="col-xs-8">
                <router-outlet></router-outlet>
            </div>
        </div>
    `
})

export class LifeCycleComponent {

}

export const lifecycleRoutes: Routes = [
    {path: "", redirectTo: "on-init", pathMatch: "full"},
    {path: "on-init", component: OnInitExample},
    {path: "on-changes", component: OnChangesExample},
    {path: "do-check-iterable", component: DoCheckIterableExample},
    {path: "do-check-object", component: DoCheckObjectExampleComponent},
    {path: "after-view-init", component: AfterViewInitExample}
];