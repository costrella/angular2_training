import {
    Component,
    Input,
    SimpleChange,
    OnChanges
} from '@angular/core';
import {API} from "../../shared/api-end-points";

@Component({
    selector: 'on-change',
    template: `
        <div class="jumbotron">
            <img width="50" src="${API.IMAGE_END_POINT}">
            <div class="content">
                {{name}}
            </div>
        </div>
    `
})
export class OnChangeCmp implements OnChanges {
    @Input('name') name: string;

    ngOnChanges(changes: { [propName: string]: SimpleChange }): void {
        let prop = Object.keys(changes)[0];
        console.log(prop, changes[prop]);
    }
}

@Component({
    selector: 'app',

    template: `
        <h4>
            OnChange
        </h4>
        <div>
            The OnChanges hook is called after one or more of our component properties/attrs have been changed.
            The ngOnChanges method receives a parameter which tells which properties have changed
        </div>
        <hr>
        Type something in input. Effect you can see in browser console.

        <div>
            <label>Name</label>
            <input type="text"
                   autofocus
                   value="{{name}}"
                   (keyup)="setValues($event.target.value)">
        </div>

        <on-change [name]="name"></on-change>
    `
})
export class OnChangesExample {
    name: string;

    constructor() {
        this.name = 'Joe Doe';
    }

    setValues(val): void {
        this.name = val;
    }
}