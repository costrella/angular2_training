import {
    Component,
    OnInit,
    OnDestroy
} from '@angular/core';


@Component({
    selector: 'on-init',
    template: `
        <div>{{time}}</div>
        <div class="badge badge-info">
            <i class="cubes icon"></i> Init/Destroy
        </div>
    `
})
export class OnInitCmp implements OnInit, OnDestroy {

    time;
    interval;

    ngOnInit(): void {
        this.interval = setInterval(() => {
            this.time = Date.now();
            console.log(this.time, this.interval.runCount);
        }, 1000);
    }

    ngOnDestroy(): void {
        console.log('On destroy');
        clearInterval(this.interval);
    }
}

@Component({
    template: `
        <div class="alert alert-info">
            Lifecycle hooks are the way Angular allows you to add code that runs before or after each step of
            the directive lifecycle. The list of hooks Angular offers are:
            <br>
            OnInit, OnDestroy, DoCheck, OnChanges, AfterContentInit,
            AfterContentChecked, AfterViewInit, AfterViewChecked
        </div>
        <hr>
        <h4>
            OnInit and OnDestroy
        </h4>
        <p>ngOnInit is a life cycle hook called by Angular2 to indicate that that Angular is done creating the
            component.
            <br>
            OnDestroy is called just before Angular destroys the directive/component.
            This is moment when you can remove listeners/intervals.
        </p>

        <button class="btn btn-primary" (click)="toggle()">
            Toggle
        </button>
        <hr>
        <on-init *ngIf="display"></on-init>
    `
})
export class OnInitExample {
    display: boolean = true;

    toggle(): void {
        this.display = !this.display;
    }
}
