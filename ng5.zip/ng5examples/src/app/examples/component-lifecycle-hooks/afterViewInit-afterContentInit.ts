import {
    Component,
    AfterContentInit,
    AfterContentChecked,
    AfterViewInit,
    AfterViewChecked, OnInit,
} from '@angular/core';

@Component({
    selector: 'afters',
    template: `
        <button class="btn btn-primary" (click)="inc()">
            Increment counter: <span class="badge badge-danger">{{ counter }}</span>
        </button>
        <hr>
        <ng-content></ng-content>
    `
})
export class AftersCmp implements OnInit, AfterContentInit,
    AfterContentChecked, AfterViewInit,
    AfterViewChecked {
    counter: number;

    constructor() {
        console.log('----- afters constructor');
        this.counter = 1;
        //debugger;
    }

    inc() {
        console.log('AfterCmd --------- [counter]');
        this.counter += 1;
    }

    ngOnInit() {
        //debugger;
    }

    ngAfterContentInit() {
        console.log('AfterCmp - AfterContentInit');
        debugger;
    }

    ngAfterContentChecked() {
        console.log('AfterCmp - AfterContentChecked');
        debugger;
    }

    ngAfterViewInit() {
        console.log('AfterCmp - AfterViewInit');
        debugger;
    }

    ngAfterViewChecked() {
        console.log('AfterCmp - AfterViewChecked');
        debugger;
    }
}

@Component({
    selector: 'app',

    template: `
        <div class="card">
            <h4 class="card-header">
                AfterContentInit, AfterViewInit, AfterContentChecked and AfterViewChecked
            </h4>

            <div class="card-body">
                1. Content is what is passed as children.
                <br>
                2. View is the template of the current component.
                <br>
                If you click toggle or increment button you will see (debugger stop/next) what happend in browser view.
                <hr>
                <div class="jumbotron">
                    <button class="btn btn-success" (click)="toggleAfters()">
                        Toggle
                    </button>
                    <afters *ngIf="displayAfters">my component content</afters>
                </div>
            </div>
        </div>
    `
})
export class AfterViewInitExample {
    displayAfters: boolean;

    constructor() {
        this.displayAfters = true;
    }

    toggleAfters(): void {
        this.displayAfters = !this.displayAfters;
    }
}