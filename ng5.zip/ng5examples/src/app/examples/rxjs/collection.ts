import {Component, Injectable, AfterViewInit} from "@angular/core";
import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Subject";
import "rxjs/add/operator/scan";
import "rxjs/add/operator/publishReplay";


export class Message {
    msg: any;

    constructor(msg) {
        this.msg = msg;
    }
}

@Injectable()
export class MessageService {
    messages: Observable<Message[]>;
    create: Subject<Message> = new Subject<Message>();

    addMessage(message: Message): void {
        this.create.next(message);
    }

    constructor() {
        this.messages = this.create
            .scan((messages: Message[], message) => {
                    return [...messages, message];
                },
                [])
            .publishReplay()
            .refCount();
    }
}

@Component({
    selector: "app",
    template: `
        <div class="jumbotron">
            <button class="btn btn-primary" (click)="add()">new msg</button>
            <hr>
            <div *ngIf="messagesService.messages | async as messages">
                <ul class="list-group">
                <li class="list-group-item" *ngFor="let msg of messages">
                    {{msg|json}}
                </li>
                </ul>
            </div>
        </div>
    `
})

export class RxCollectionExample {

    constructor(public messagesService: MessageService) {

    }

    add() {
        let msg = new Message(Date.now().toString());
        this.messagesService.addMessage(msg);
    }
}