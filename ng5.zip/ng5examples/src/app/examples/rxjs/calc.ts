import {Component, AfterViewInit, ViewChild} from "@angular/core";
import {Observable} from "rxjs/Observable";
import "rxjs/add/observable/fromEvent";
import "rxjs/add/observable/combineLatest";
import "rxjs/add/operator/filter";

@Component({
    selector: "app",
    templateUrl: "./calc.html"
})

export class RxCalorieCalcExample implements AfterViewInit {
    @ViewChild('weight') weight: any;
    @ViewChild('activity') activity: any;
    @ViewChild('output') output: any;
    result: number;

    ngAfterViewInit() {

        let needsStream = Observable
            .combineLatest(
                Observable.fromEvent(this.weight.nativeElement, 'input'),
                Observable.fromEvent(this.activity.nativeElement, 'input'),
                (weightEvent: Event, activityEvent: Event)=> {
                    let weight = +(weightEvent.target as HTMLInputElement).value,
                        activity = +(activityEvent.target as HTMLInputElement).value;
                    return {weight, activity};
                });
        
        needsStream
            .subscribe(()=> this.result = 0);

        needsStream
            .filter(obj=> obj.weight > 0 && obj.activity >= 1 && obj.activity <= 1.6)
            .map(obj=> (obj.weight * 24 * obj.activity).toFixed())
            .subscribe(result=> this.result = +result);
    }
}
