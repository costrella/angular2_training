import {AfterViewInit, Component, ViewChild} from "@angular/core";
import {Observable} from "rxjs/Observable";
import "rxjs/add/observable/interval";
import "rxjs/add/observable/fromEvent";
import "rxjs/add/operator/takeWhile";
import "rxjs/add/operator/withLatestFrom";

@Component({
    selector: "app",
    styles: [`
        .score, .count {
            font-size: 20px;
        }

        .board {
            width: 500px;
            height: 300px;
            background-color: darkslategray;
        }

        .dot {
            background-color: orange;
            display: inline-block;
            border-radius: 25px;
            width: 50px;
            height: 50px;
            position: absolute;
            cursor: pointer;
            left: -1000px;
        }
    `],
    template: `
        <div class="">
            <h4>collect points by ball clicking</h4>
            <button [disabled]="activity" class="btn btn-primary" (click)="run()">run</button>
            <div class="badge badge-success">
                <span class="score" #score>0</span> / <span class="count" #count>0</span>
            </div>
            <div class="board" #board></div>
            <div class="dot" #dot></div>
        </div>`
})

export class RxGameExample implements AfterViewInit {

    @ViewChild('dot') dot: any;
    @ViewChild('score') score: any;
    @ViewChild('count') count: any;
    @ViewChild('board') board: any;

    dotEl;
    scoreEl;
    countEl;
    intervalTime: number = 1200;
    limit = 5;
    activity: boolean;

    ngAfterViewInit(): void {
        this.dotEl = this.dot.nativeElement;
        this.scoreEl = this.score.nativeElement;
        this.countEl = this.count.nativeElement;
        this.board = this.board.nativeElement;
    }

    run() {

        this.activity = true;
        this.scoreEl.innerHTML = 0;
        this.countEl.innerHTML = 0;

        const dot$ = Observable
            .interval(this.intervalTime)
            .map(e => e + 1);

        dot$
            .takeWhile(e => {
                if (e <= this.limit) {
                    return true;
                } else {
                    this.activity = false;
                }
            })
            .subscribe(e => {
                this.setDotPosition();
                this.countEl.innerHTML = e;
            });

        let hit$ = Observable
            .fromEvent(this.dotEl, 'click')
            .scan(e => {
                this.dotEl.style.display = 'none';
                return +e + 1;
            }, 0)
            .withLatestFrom(dot$, (hit, dot) => {
                return {hit: hit, dot: dot};
            })
            .filter(e => {
                return e.dot <= this.limit;
            });

        hit$
            .subscribe(e => {
                this.dotEl.style.display = 'none';
                this.scoreEl.innerHTML = e.hit;
            });
    }

    setDotPosition() {

        const x = (Math.random() * (this.board.clientWidth - this.dotEl.offsetWidth)) + this.board.offsetLeft,
            y = (Math.random() * (this.board.clientHeight - this.dotEl.offsetHeight)) + this.board.offsetTop;

        this.dotEl.style.left = x + 'px';
        this.dotEl.style.top = y + 'px';
        this.dotEl.style.display = 'block';
    }
}