import {Component, OnInit} from "@angular/core";
import {API} from "../../shared/api-end-points";
import {HttpClient} from "@angular/common/http";

@Component({
    selector: 'items',
    template: `
        <span class="badge badge-info" *ngIf="items">items amount: {{ items.length }}</span>
        <button class="btn btn-sm btn-primary" (click)="signIn()">sign in</button>
        <span class="badge" [class.badge-success]="access" [class.badge-danger]="!access">access: {{access}}</span>
        <span class="badge badge-danger" [hidden]="!updating">updating...</span>
        <hr>
        <div class="badge badge-warning">You can update price after login</div>
        <ul class="list-group">
            <li *ngFor="let item of items" class="list-group-item">
                {{item.title}} -
                <input type="number"
                       [disabled]="!access"
                       [value]="item.price"
                       (input)="update(item, $event.target.value)">
            </li>
        </ul>`
})
export class Items implements OnInit {

    items: {}[];
    access: boolean = false;
    updating: boolean = false;

    constructor(private http: HttpClient) {
        this.isAuthenticated()
    }

    update(item, price) {
        this.updating = true;
        item.price = price;
        this.http
            .put(API.ITEMS_END_POINT, item, {withCredentials: true})
            .subscribe(response => this.updating = false)
    }

    signIn() {
        return this.http
            .post<{ok}>(API.LOGIN_END_POINT, {login: 'admin', password: 'admin'}, {withCredentials: true})
            .subscribe(({ok}) => this.access = ok);
    }

    // Implement this interface to execute custom initialization logic after your directive's data-bound properties have been initialized.
    ngOnInit() {
        this.http
            .get<{data}>(API.ITEMS_END_POINT)
            .subscribe(({data}) => this.items = data);
    }

    isAuthenticated() {
        this.http
            .get<{ok}>(API.IS_AUTHENTICATED)
            .subscribe(({ok}) => this.access = ok);
    }
}
