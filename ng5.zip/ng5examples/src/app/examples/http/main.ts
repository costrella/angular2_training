import {Component} from "@angular/core";

@Component({
    selector: "app",
    template: `
        <items></items>
    `
})

export class HttpExample {

}