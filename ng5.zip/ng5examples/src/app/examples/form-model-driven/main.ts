import {Component} from "@angular/core";

@Component({
    template: `
        <div class="card">
            <div class="card-header">MODEL DRIVEN FORM</div>
            <div class="card-body">
                <form-with-formgroup></form-with-formgroup>
            </div>
        </div>`
})

export class FormModelDrivenExample {

}