import {Component, OnInit} from "@angular/core";
import {CustomValidators} from "./custom-validators";
import {FormControl, FormGroup, Validators} from "@angular/forms";

import {Observable} from "rxjs/Observable";
import {API} from "../../shared/api-end-points";
import "rxjs/add/operator/map";
import {HttpClient} from "@angular/common/http";

@Component({
    selector: 'form-with-formgroup',
    templateUrl: "./form-model-driven.html"
})
export class FormWithFormGroup implements OnInit {
    myForm: FormGroup;

    constructor(private http: HttpClient) {

    }

    /**
     * Server valdation - try joe@doe.com
     */
    checkEmail(control): Observable<any> {
        return this.http
            .post<{ok,error, data}>(API.END_POINT_PREFIX + 'check-email', {email: control.value})
            .map(({ok, error, data}) => {
                if (!ok) {
                    return {emailRequired: error};
                }
            });
    }

    ngOnInit() {
        this.myForm = new FormGroup({
            sku: new FormControl('', Validators.compose([
                Validators.required,
                CustomValidators.skuValidator
            ])),
            nip: new FormControl('', CustomValidators.nipValidator),
            email: new FormControl('', Validators.email, this.checkEmail.bind(this)),
            gender: new FormControl('', Validators.required),
            interests: new FormGroup({
                sport: new FormControl(''),
                music: new FormControl(''),
                technology: new FormControl('')
            }, CustomValidators.atLeastOneIsRequired),
            nationality: new FormControl('', Validators.required)

        });

        this.myForm
            .valueChanges
            .subscribe(changes => {
                console.log('changes', changes);
            })
    }

    onSubmit(form): void {
        if (form.valid) {
            console.log('you submitted value: ', form.value);
        } else {
            console.log('form invalid');
        }
    }
}