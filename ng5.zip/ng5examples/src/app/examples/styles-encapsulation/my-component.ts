import {Component, ViewEncapsulation} from "@angular/core";

@Component({
    selector: "my-component",
    styles: [`
        h3 {
            border: solid red;
        }

        p {
            color: tomato;
        }
    `],
    /**
     * default
     * tworzy style izolowane dla tego komponentu.
     * style zewnętrzne/globalne również oddziałują na komponent; działają style bootstrap np. card
     */
    //encapsulation: ViewEncapsulation.Emulated,
    /**
     * tworzy style izolowane dla tego komponentu.
     * style zewnętrzne nie oddziaływują na ten element
     * tworzy tzw. shadowDom element który jest root'em dla komponentu oraz styli.
     */
    //encapsulation: ViewEncapsulation.Native,
    /**
     * tworzy style globalne w znaczniku head.
     */
    //encapsulation: ViewEncapsulation.None,
    template: `
        <div class="card card-body">
            <h3>h3 tag in component</h3>
            <small>small tag in component</small>
            <p>p tag in component</p>
        </div>`
})

export class MyComponent {

}
