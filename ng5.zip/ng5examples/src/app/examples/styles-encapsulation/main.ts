import {Component} from "@angular/core";

@Component({
    selector: "app",
    styles: [`
        h3 {
            border: solid green
        }

        small {
            color: silver
        }
    `],
    template: `
        <h2>styles encapsulation</h2>
        <hr>

        <div class="card card-body">
            <h3>h3 tag in parent</h3>
            <small>smal tag in parent</small>
            <p>p tag in parent</p>
            <my-component></my-component>
        </div>
    `
})
export class StylesEncapsulationExample {
    constructor() {

    }
}