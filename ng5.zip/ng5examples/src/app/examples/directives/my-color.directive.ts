import {
    Directive, Input, ElementRef, Renderer, HostListener
} from '@angular/core';

@Directive({
    selector: '[myColor]'
})
export class MyColorDirective {

    @Input() myColor;

    constructor(private el: ElementRef,
                private renderer: Renderer) {
    }

    @HostListener('mouseenter') onMouseEnter() {
        this.setBorder(this.myColor);
    }

    @HostListener('mouseleave') onMouseLeave() {
        this.setBorder('white');
    }

    setBorder(color) {
        this.renderer.setElementStyle(this.el.nativeElement, 'backgroundColor', color);
    }

}
