import {Component} from "@angular/core";
import {Observable} from "rxjs/Observable";
import "rxjs/add/observable/interval";

@Component({
    selector: "app",
    template: `
        <div class="card" [myColor]="'pink'">
            <h4 class="card-header">Angular directives: NgIf, NgSwitch, NgStyle, NgClass, NgFor</h4>
            <div class="card-body">
                <h3 *ngIf="access">you have access</h3>
                <h3 *ngIf="!access">you have no access</h3>
                <hr>
                <h1 [ngStyle]="{'font-size': style.size, 'color': style.color}">
                    Change style of this text!
                </h1>
                <hr>
                <h2 [ngClass]="myClass">my class name</h2>
                <h2 [ngClass]="{'text-success':access}">text-success class when access</h2>
                <h2 [class.text-danger]="access">text-danger class when access</h2>
                <hr>
                <ul class="list-unstyled">
                    <li *ngFor="let item of items; let idx=index">{{idx + 1}}. {{item}}</li>
                </ul>
                <hr>
                <div [ngSwitch]="tik">
                    <h1 *ngSwitchCase="1">the biggest {{tik}}</h1>
                    <h2 *ngSwitchCase="2">very big {{tik}}</h2>
                    <h3 *ngSwitchCase="3">quite big {{tik}}</h3>
                    <h4 *ngSwitchCase="4">medium {{tik}}</h4>
                    <h5 *ngSwitchCase="5">small {{tik}}</h5>
                    <h6 *ngSwitchCase="6">very small {{tik}}</h6>
                    <p *ngSwitchDefault>default {{tik}}</p>
                </div>
            </div>
        </div>
    `
})

export class DirectivesNgExamples {
    access: boolean = true;
    tik: number;
    style = {
        size: "33px",
        color: "coral"
    };
    myClass: string = "text-danger";
    items: Array<string> = ['Joe', 'Mike', 'Kate'];

    constructor() {
        Observable
            .interval(1000)
            .map(val => {
                return val % 6 + 1;
            })
            .subscribe(val => this.tik = val);
    }
}
