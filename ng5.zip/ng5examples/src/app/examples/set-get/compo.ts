import {Component} from "@angular/core";

@Component({
    selector: 'compo',
    inputs: ['inn'],
    template: `
        <div class="card card-body">
            geter: {{inn}}
        </div>`
})

export class Compo {
    status: string;

    set inn(val) {
        this.status = val;
    }

    get inn() {
        return this.status;
    }
}
