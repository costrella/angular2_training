import {Component} from "@angular/core";

@Component({
    selector: 'app',
    template: `
        <div class="card">
            <h4 class="card-header">
                Przykład pokazuje użycie metod set/get w klasie.
            </h4>
            <div class="card-body">
                seter
                <input class="form-control" autofocus (input)="result = $event.target.value">
                <hr>
                <compo [inn]="result"></compo>
            </div>
        </div>
    `
})

export class SetGetExample {
    result: string;
}
