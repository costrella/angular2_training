import {Component, ElementRef} from "@angular/core";
import {FileUpload} from "./file-upload";
import {API} from "../../shared/api-end-points";

@Component({
    selector: "app",
    template: `
        <file-upload
                [url]="'${API.UPLOAD_END_POINT}'"
                (uploaded)="uploaded($event)">
        </file-upload>`
})

export class UploadComponentExample {
    constructor(private el: ElementRef) {

    }

    uploaded(imgSrc) {
        let img = new Image(100);
        img.src = imgSrc;
        this.el.nativeElement.appendChild(img);
    }
}
