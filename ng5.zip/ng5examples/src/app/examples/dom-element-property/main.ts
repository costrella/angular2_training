import {Component} from "@angular/core";
import {API} from "../../shared/api-end-points";

@Component({
    selector: "app",
    templateUrl: "./dom-element-prop-example.html"
})
export class DomElementPropertyExample {
    userName: string = "Jeo";
    access: boolean = false;
    editable: boolean = true;
    myTags: string = `<h3>template</h3><img width="100" src='${API.IMAGE_END_POINT}'>`;
}
