import {Component} from '@angular/core';

@Component({
    template: `
        <h1>szkolenie Angular | przykłady</h1>

        <div>
            <div>
                Zobacz inne szkolenia
            </div>

            <ul>
                <li><a target="_blank" href="https://debugger.pl/szkolenie-angular-5">
                    SZKOLENIE ANGULAR 5
                </a></li>
                <li><a target="_blank" href="https://debugger.pl/szkolenie-angularjs">
                    SZKOLENIE ANGULARJS
                </a></li>
                <li><a target="_blank" href="https://debugger.pl/szkolenie-javascript-podstawy">
                    SZKOLENIE JAVASCRIPT PODSTAWY
                </a></li>
                <li><a target="_blank" href="https://debugger.pl/szkolenie-javascript-zaawansowane">
                    SZKOLENIE JAVASCRIPT ZAAWANSOWANE
                </a></li>
                <li><a target="_blank" href="https://debugger.pl/szkolenie-nodejs-i-mongodb">
                    SZKOLENIE NODEJS I MONGODB
                </a></li>
                <li><a target="_blank" href="https://debugger.pl/szkolenie-testy-automatyczne">
                    SZKOLENIE TESTY AUTOMATYCZNE
                </a></li>
                <li><a target="_blank" href="https://debugger.pl/szkolenie-web-components">
                    SZKOLENIE WEB COMPONENTS
                </a></li>
            </ul>
        </div>
    `
})
export class InitComponent {

}