import {Component} from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styles: [`        
        .btn {
            margin: 2px 0;
        }
        a:active, .btn:active, a:focus, .btn:focus, a:hover, .btn:hover{
            box-shadow: none !important;
        }
        .active {
            color: darkred;
            background-color: white;
        }
    `]
})
export class AppComponent {

}
