import {RouterModule, Routes} from '@angular/router';
import {ComponentExample} from './examples/component/main';
import {DirectivesNgExamples} from './examples/directives/main';
import {MouseAndKeyEventsExamples} from './examples/mouse-and-key-events/main';
import {DomElementPropertyExample} from './examples/dom-element-property/main';
import {ServiceExample} from './examples/service/main';
import {PipesExample} from './examples/pipes/main';
import {SetGetExample} from './examples/set-get/main';
import {StylesEncapsulationExample} from './examples/styles-encapsulation/main';
import {HttpExample} from './examples/http/main';
import {RxCalorieCalcExample} from './examples/rxjs/calc';
import {RxGameExample} from './examples/rxjs/game';
import {RxCollectionExample} from './examples/rxjs/collection';
import {FormModelDrivenExample} from './examples/form-model-driven/main';
import {RoutesExample, routesExampleRoutes} from './examples/routes/main';
import {UploadComponentExample} from './examples/upload/main';
import {NgBootstrapExample} from './examples/ng-bootstrap/main';
import {InitComponent} from './init.component';
import {LifeCycleComponent, lifecycleRoutes} from './examples/component-lifecycle-hooks/main';
import {FormTemplateDrivenExample} from './examples/form-template-driven/main';

const routes: Routes = [
    {path: '', component: InitComponent},
    {path: 'component', component: ComponentExample},
    {path: 'directives-ng', component: DirectivesNgExamples},
    {path: 'mouse-and-key-event', component: MouseAndKeyEventsExamples},
    {path: 'dom-element-property', component: DomElementPropertyExample},
    {path: 'service', component: ServiceExample},
    {path: 'pipes', component: PipesExample},
    {path: 'set-get', component: SetGetExample},
    {path: 'styles-encapsulation', component: StylesEncapsulationExample},
    {path: 'http', component: HttpExample},
    {path: 'rxjs-calc', component: RxCalorieCalcExample},
    {path: 'rxjs-game', component: RxGameExample},
    {path: 'rxjs-collection', component: RxCollectionExample},
    {path: 'form-model-driven', component: FormModelDrivenExample},
    {path: 'form-template-driven', component: FormTemplateDrivenExample},
    {path: 'routes', component: RoutesExample, children: routesExampleRoutes},
    {path: 'upload', component: UploadComponentExample},
    {path: 'ng-bootstrap', component: NgBootstrapExample},
    {path: 'lifecycle', component: LifeCycleComponent, children: lifecycleRoutes},
    {path: '**', component: InitComponent}
];

export const routing = RouterModule.forRoot(routes);
